import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:math' as math;

enum AppLanguage {
  system('跟随系统', null),
  simplified('简体中文', Locale('zh', 'CN')),
  hongKong('繁體中文 · 香港', Locale('zh', 'HK')),
  taiwan('繁體中文 · 台灣', Locale('zh', 'TW')),
  vietnamese('Tiếng Việt', Locale('vi', 'VN'));

  const AppLanguage(this.label, this.locale);
  final String label;
  final Locale? locale;
  static AppLanguage fromRecord(Object? value) =>
      values.firstWhere((v) => v.name == value, orElse: () => system);
}

Locale chineseLocale(Locale? locale) => Locale(
  'zh',
  locale?.countryCode == 'HK' || locale?.countryCode == 'MO'
      ? 'HK'
      : locale?.countryCode == 'TW' || locale?.scriptCode == 'Hant'
      ? 'TW'
      : 'CN',
);

/// Offline OpenCC dictionary conversion. Text is converted once per bounded
/// cache entry, never in a painter or on a scroll/animation callback.
abstract final class ChineseText {
  static Future<void>? _loading;
  static Map<String, _Lexicon> _lexicons = {};
  static final _cache = <(String, bool, String), String>{};
  static int _cacheUnits = 0;
  static Future<_Lexicon>? _searchLexicon;

  /// Normalize queries for the simplified catalogue, not the user's stored
  /// book text or display preference. Dictionaries load only on first search.
  static Future<String> searchQuery(String source) async {
    if (!RegExp(r'[\u3400-\u9fff]').hasMatch(source)) return source;
    final lexicon = await (_searchLexicon ??= () async {
      const names = ['TSPhrases', 'TSCharacters'];
      final sources = await Future.wait([
        for (final name in names)
          rootBundle.loadString('assets/opencc/$name.txt'),
      ]);
      return compute(_readSearchLexicon, sources);
    }());
    return lexicon.convert(source);
  }

  static Future<List<String>> readerParagraphs(
    List<String> paragraphs,
    Locale locale,
  ) async {
    final region = chineseLocale(locale).countryCode!;
    if (region == 'CN') return paragraphs;
    final job = (paragraphs: paragraphs, region: region, lexicons: _lexicons);
    if (paragraphs.fold<int>(0, (sum, p) => sum + p.length) > 32 * 1024) {
      return compute(_readerParagraphs, job);
    }
    return _readerParagraphs(job);
  }

  static Future<void> prepare() => _loading ??= () async {
    const names = [
      'STCharacters',
      'STPhrases',
      'TWVariants',
      'HKVariants',
      'TWPhrasesIT',
      'TWPhrasesName',
      'TWPhrasesOther',
    ];
    final sources = await Future.wait(
      names.map((n) => rootBundle.loadString('assets/opencc/$n.txt')),
    );
    _lexicons = await compute(_readLexicons, {
      for (var i = 0; i < names.length; i++) names[i]: sources[i],
    });
  }();

  static String convert(String source, Locale locale, {bool reader = false}) {
    final region = chineseLocale(locale).countryCode!;
    if (region == 'CN' || source.isEmpty || _lexicons.isEmpty) return source;
    final key = (region, reader, source);
    final hit = _cache.remove(key);
    if (hit != null) {
      _cache[key] = hit;
      return hit;
    }
    var text = _lexicons['standard']!.convert(source, preserveOffsets: reader);
    if (region == 'TW' && !reader) text = _lexicons['phrases']!.convert(text);
    text = _lexicons[region]!.convert(text, preserveOffsets: reader);
    if (source.length < 8192) {
      _cache[key] = text;
      _cacheUnits += source.length + text.length;
      while (_cache.length > 2048 || _cacheUnits > 256 * 1024) {
        final oldest = _cache.keys.first;
        _cacheUnits -= oldest.$3.length + _cache.remove(oldest)!.length;
      }
    }
    return text;
  }
}

List<String> _readerParagraphs(
  ({List<String> paragraphs, String region, Map<String, _Lexicon> lexicons})
  job,
) => [
  for (final text in job.paragraphs)
    text.trim() == '[插图]' ||
            text.trimLeft().startsWith('<!--image-->') ||
            job.lexicons.isEmpty
        ? text
        : job.lexicons[job.region]!.convert(
            job.lexicons['standard']!.convert(text, preserveOffsets: true),
            preserveOffsets: true,
          ),
];

class _Lexicon {
  _Lexicon(this.words) {
    for (final key in words.keys) {
      final head = key.codeUnitAt(0);
      if ((_longest[head] ?? 0) < key.length) _longest[head] = key.length;
    }
  }
  final Map<String, String> words;
  final _longest = <int, int>{};
  String convert(String input, {bool preserveOffsets = false}) {
    final out = StringBuffer();
    for (var i = 0; i < input.length;) {
      final bound = (_longest[input.codeUnitAt(i)] ?? 0).clamp(
        0,
        input.length - i,
      );
      String? value;
      var length = bound;
      for (; length > 0; length--) {
        value = words[input.substring(i, i + length)];
        if (value != null && (!preserveOffsets || value.length == length)) {
          break;
        }
        value = null;
      }
      if (value == null) {
        out.writeCharCode(input.codeUnitAt(i++));
      } else {
        out.write(value);
        i += length;
      }
    }
    return out.toString();
  }
}

_Lexicon _readSearchLexicon(List<String> sources) {
  final words = <String, String>{};
  for (final source in sources) {
    for (final line in source.split('\n')) {
      if (line.isEmpty || line.startsWith('#')) continue;
      final fields = line.trim().split('\t');
      if (fields.length == 2) {
        words.putIfAbsent(fields[0], () => fields[1].split(' ').first);
      }
    }
  }
  return _Lexicon(words);
}

Map<String, _Lexicon> _readLexicons(Map<String, String> sources) {
  Map<String, String> read(List<String> names) {
    final words = <String, String>{};
    for (final name in names) {
      for (final line in sources[name]!.split('\n')) {
        if (line.isEmpty || line.startsWith('#')) continue;
        final fields = line.trim().split('\t');
        if (fields.length == 2) {
          words.putIfAbsent(fields[0], () => fields[1].split(' ').first);
        }
      }
    }
    return words;
  }

  return {
    'standard': _Lexicon(read(['STPhrases', 'STCharacters'])),
    'TW': _Lexicon(read(['TWVariants'])),
    'HK': _Lexicon(read(['HKVariants'])),
    'phrases': _Lexicon(
      read(['TWPhrasesIT', 'TWPhrasesName', 'TWPhrasesOther']),
    ),
  };
}

const Map<String, String> _vietnameseUi = {
  '重试': 'Thử lại',
  '取消': 'Hủy',
  '继续加载': 'Tiếp tục tải',
  '个人批注': 'Ghi chú cá nhân',
  '章内查找': 'Tìm trong chương',
  '整书查找': 'Tìm trong toàn bộ sách',
  '使用此颜色': 'Dùng màu này',
  '整体布局': 'Bố cục tổng thể',
  '正在加载…': 'Đang tải…',
  '保存': 'Lưu',
  '清空': 'Xóa tất cả',
  '显示书籍信息': 'Hiển thị thông tin sách',
  '允许 HTTP 连接': 'Cho phép kết nối HTTP',
  '重试主题图片': 'Thử tải lại ảnh chủ đề',
  '自动匹配': 'Tự động khớp',
  '批注': 'Ghi chú',
  '清空搜索记录': 'Xóa lịch sử tìm kiếm',
  '最近搜索': 'Tìm kiếm gần đây',
  '查找': 'Tìm',
  '暂不合并': 'Chưa hợp nhất',
  '视图': 'Giao diện',
  '返回阅读': 'Quay lại đọc',
  '查看书签与划线': 'Xem dấu trang và đoạn đánh dấu',
  '查看账号连接': 'Xem kết nối tài khoản',
  '全部强度': 'Toàn bộ cường độ',
  '已分别设置': 'Đã thiết lập riêng',
  '按交互调整': 'Điều chỉnh theo thao tác',
  '此设备没有可用的振动马达。': 'Thiết bị này không có mô-tơ rung.',
  '强度由系统控制': 'Cường độ do hệ thống điều khiển',
  '试振': 'Thử rung',
  '保留的效果': 'Hiệu ứng được giữ lại',
  '恢复轻量预设': 'Khôi phục cấu hình nhẹ',
  '帧率偏好': 'Tùy chọn tốc độ khung hình',
  '系统自动调度': 'Hệ thống tự động điều chỉnh',
  '重新读取': 'Đọc lại',
  '预览效果': 'Xem trước hiệu ứng',
  '自选颜色': 'Màu tùy chỉnh',
  '更换封面': 'Đổi ảnh bìa',
  '恢复封面': 'Khôi phục ảnh bìa',
  '移除书籍': 'Xóa sách',
  '加载更多': 'Tải thêm',
  '重新载入': 'Tải lại',
  '批量整理本地书': 'Sắp xếp hàng loạt sách trên thiết bị',
  '主题配色': 'Màu chủ đề',
  '字体': 'Phông chữ',
  '离线词典': 'Từ điển ngoại tuyến',
  '低性能设备模式': 'Chế độ thiết bị cấu hình thấp',
  '恢复默认': 'Khôi phục mặc định',
  '减少动态效果': 'Giảm hiệu ứng chuyển động',
  '振动反馈': 'Phản hồi rung',
  '阅读历史': 'Lịch sử đọc',
  '缓存管理': 'Quản lý bộ nhớ đệm',
  '备份与恢复': 'Sao lưu và khôi phục',
  '管理屏蔽标签': 'Quản lý thẻ bị chặn',
  '暂无章节': 'Chưa có chương',
  '书籍详情加载失败': 'Không thể tải thông tin sách',
  '上次阅读': 'Đọc lần trước',
  '图书详情': 'Chi tiết sách',
  '下一章': 'Chương tiếp theo',
  '已读至当前目录末章': 'Đã đọc đến chương cuối trong mục lục',
  '导入问题': 'Sự cố nhập dữ liệu',
  '连接位置': 'Vị trí kết nối',
  '同步内容': 'Nội dung đồng bộ',
  '断开连接': 'Ngắt kết nối',
  '新建同步文件': 'Tạo tệp đồng bộ mới',
  '选择已有文件': 'Chọn tệp hiện có',
  '在其他设备上续读': 'Tiếp tục đọc trên thiết bị khác',
  '开启跟随': 'Bật theo dõi',
  '打开链接': 'Mở liên kết',
  '复制链接': 'Sao chép liên kết',
  '添加': 'Thêm',
  '完成': 'Hoàn tất',
  '离线缓存': 'Bộ nhớ đệm ngoại tuyến',
  '取消缓存': 'Hủy lưu bộ nhớ đệm',
  '继续缓存': 'Tiếp tục lưu bộ nhớ đệm',
  '暂无离线缓存，在图书详情中缓存章节。': 'Chưa có dữ liệu ngoại tuyến. Hãy lưu chương trong phần chi tiết sách.',
  '暂无阅读历史': 'Chưa có lịch sử đọc',
  '云端收藏': 'Yêu thích trên đám mây',
  '推荐作品': 'Tác phẩm đề xuất',
  '评论': 'Bình luận',
  '分享': 'Chia sẻ',
  '榜单': 'Bảng xếp hạng',
  '标签': 'Thẻ',
  '出版文库': 'Thư viện xuất bản',
  '屏蔽': 'Chặn',
  '分钟': 'phút',
  '目录': 'Mục lục',
  '正在阅读': 'Đang đọc',
  '已缓存': 'Đã lưu ngoại tuyến',
  '登录': 'Đăng nhập',
  '刷新资料': 'Làm mới thông tin',
  '退出账号': 'Đăng xuất',
  '合并到本机': 'Hợp nhất vào thiết bị',
  '合并到云端': 'Hợp nhất lên đám mây',
  '云书架还没有收藏': 'Giá sách đám mây chưa có sách yêu thích',
  '竖屏': 'Dọc',
  '横屏': 'Ngang',
  '少': 'Ít',
  '多': 'Nhiều',
  '重试插图': 'Thử tải lại hình minh họa',
  '重新读取插图': 'Đọc lại hình minh họa',
  '本卷没有找到插图。': 'Không tìm thấy hình minh họa trong tập này.',
  '按作者分类': 'Phân loại theo tác giả',
  '保存到本地书库': 'Lưu vào thư viện trên thiết bị',
  '移动到书库': 'Chuyển vào thư viện',
  '关联原文件': 'Liên kết với tệp gốc',
  '复制到书库': 'Sao chép vào thư viện',
  '书籍信息': 'Thông tin sách',
  '语言': 'Ngôn ngữ',
  '简体中文': 'Tiếng Trung giản thể',
  '繁體中文 · 香港': 'Tiếng Trung phồn thể · Hồng Kông',
  '繁體中文 · 台灣': 'Tiếng Trung phồn thể · Đài Loan',
}; 

String appText(BuildContext context, String value) {
  final locale = Localizations.maybeLocaleOf(context) ?? const Locale('zh', 'CN');
  if (locale.languageCode == 'vi') return _vietnameseUi[value] ?? value;
  return ChineseText.convert(value, locale);
}

/// All ordinary app labels share the locale; book source data stays unchanged.
class AppText extends StatefulWidget {
  const AppText(
    this.data, {
    super.key,
    this.style,
    this.strutStyle,
    this.textAlign,
    this.textDirection,
    this.locale,
    this.softWrap,
    this.overflow,
    this.textScaler,
    this.maxLines,
    this.semanticsLabel,
    this.textWidthBasis,
    this.textHeightBehavior,
    this.selectionColor,
  });
  final String data;
  final TextStyle? style;
  final StrutStyle? strutStyle;
  final TextAlign? textAlign;
  final TextDirection? textDirection;
  final Locale? locale;
  final bool? softWrap;
  final TextOverflow? overflow;
  final TextScaler? textScaler;
  final int? maxLines;
  final String? semanticsLabel;
  final TextWidthBasis? textWidthBasis;
  final TextHeightBehavior? textHeightBehavior;
  final Color? selectionColor;
  @override
  State<AppText> createState() => _AppTextState();
}

class _AppTextState extends State<AppText> with SingleTickerProviderStateMixin {
  AnimationController? _motion;
  String? _region, _value;
  List<String> _from = const [], _to = const [];
  List<double> _delays = const [];
  int _generation = 0;
  void _sync() {
    final region = chineseLocale(
      Localizations.maybeLocaleOf(context),
    ).countryCode;
    final next = appText(context, widget.data);
    if (_region != null &&
        _region != region &&
        widget.data.length <= 512 &&
        !MediaQuery.disableAnimationsOf(context) &&
        TickerMode.valuesOf(context).enabled) {
      _from = (_value ?? next).characters.toList();
      _to = next.characters.toList();
      final random = math.Random(widget.data.hashCode ^ ++_generation);
      _delays = List.generate(
        math.max(_from.length, _to.length),
        (_) => random.nextDouble() * .52,
      );
      (_motion ??= AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 780),
      )).forward(from: 0);
    } else if (_value != next ||
        _region != region ||
        MediaQuery.disableAnimationsOf(context)) {
      _motion?.stop();
      _motion?.value = 1;
    }
    _region = region;
    _value = next;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _sync();
  }

  @override
  void didUpdateWidget(AppText oldWidget) {
    super.didUpdateWidget(oldWidget);
    _sync();
  }

  @override
  void dispose() {
    _motion?.dispose();
    super.dispose();
  }

  Widget _text({InlineSpan? span}) {
    final label = widget.semanticsLabel == null
        ? null
        : appText(context, widget.semanticsLabel!);
    if (span == null) {
      return Text(
        _value ?? appText(context, widget.data),
        style: widget.style,
        strutStyle: widget.strutStyle,
        textAlign: widget.textAlign,
        textDirection: widget.textDirection,
        locale: widget.locale,
        softWrap: widget.softWrap,
        overflow: widget.overflow,
        textScaler: widget.textScaler,
        maxLines: widget.maxLines,
        semanticsLabel: label,
        textWidthBasis: widget.textWidthBasis,
        textHeightBehavior: widget.textHeightBehavior,
        selectionColor: widget.selectionColor,
      );
    }
    return Text.rich(
      span,
      style: widget.style,
      strutStyle: widget.strutStyle,
      textAlign: widget.textAlign,
      textDirection: widget.textDirection,
      locale: widget.locale,
      softWrap: widget.softWrap,
      overflow: widget.overflow,
      textScaler: widget.textScaler,
      maxLines: widget.maxLines,
      semanticsLabel: label ?? _value,
      textWidthBasis: widget.textWidthBasis,
      textHeightBehavior: widget.textHeightBehavior,
      selectionColor: widget.selectionColor,
    );
  }

  @override
  Widget build(BuildContext context) {
    final motion = _motion;
    if (motion == null || motion.value == 1) return _text();
    return AnimatedBuilder(
      animation: motion,
      builder: (context, _) {
        if (motion.value == 1) return _text();
        final color =
            widget.style?.color ??
            DefaultTextStyle.of(context).style.color ??
            Theme.of(context).colorScheme.onSurface;
        return _text(
          span: TextSpan(
            children: [
              for (var i = 0; i < _delays.length; i++)
                _character(i, motion.value, color),
            ],
          ),
        );
      },
    );
  }

  InlineSpan _character(int i, double clock, Color color) {
    final t = ((clock - _delays[i]) / .48).clamp(0.0, 1.0);
    final alpha = (t < .5 ? 1 - t * 1.84 : .08 + (t - .5) * 1.84).clamp(
      .08,
      1.0,
    );
    final chars = t < .5 ? _from : _to;
    return TextSpan(
      text: i < chars.length ? chars[i] : '',
      style: TextStyle(color: color.withValues(alpha: color.a * alpha)),
    );
  }
}
