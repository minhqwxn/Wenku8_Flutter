# Wenku8 Flutter – bản bổ sung tiếng Việt (bản thử nghiệm)

## Những gì đã thay đổi
- Thêm lựa chọn ngôn ngữ **Tiếng Việt** (`vi_VN`) trong danh sách ngôn ngữ.
- Đăng ký locale tiếng Việt cho Flutter Material.
- Bổ sung bản dịch tiếng Việt cho một nhóm nhãn giao diện thường dùng.
- Giữ nguyên dữ liệu truyện, tài khoản, đồng bộ và các chức năng gốc.

## Lưu ý
Đây là **bản Việt hóa bước đầu**, chưa phải bản dịch toàn bộ. Một số màn hình, thông báo động, nội dung do Wenku8 trả về và một số nhãn viết trực tiếp bằng `Text` vẫn có thể hiển thị tiếng Trung. Nội dung tiểu thuyết không được tự động dịch.

## Biên dịch APK Android ARM64
Cần cài Flutter SDK tương thích với Dart SDK `^3.11.3`, Android SDK và Java phù hợp.

Mở terminal tại thư mục dự án rồi chạy:

```bash
flutter pub get
flutter build apk --release --target-platform android-arm64
```

APK thường được tạo tại:

```text
build/app/outputs/flutter-apk/app-release.apk
```

Nếu cài đè lên bản gốc mà Android báo xung đột chữ ký, cần gỡ bản cũ trước (việc này có thể xóa dữ liệu ứng dụng nếu chưa sao lưu), hoặc ký bản mới bằng cùng khóa ký của bản đang cài.

## Chọn Tiếng Việt
Sau khi cài APK, mở phần Cài đặt ngôn ngữ trong ứng dụng và chọn **Tiếng Việt**.
